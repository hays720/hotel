-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 28, 2018 at 12:51 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment_list_content`
--

CREATE TABLE `comment_list_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comment_list_content`
--

INSERT INTO `comment_list_content` (`id`, `comment`, `name`) VALUES
(3, 'Рекомендую ,якщо потрібний відпочинок після кордону ,його перетину ,кордон Ягодин ,чисте і комфортне місце', 'Роман Заєць'),
(4, 'Місце чудове,кухня смачна,обслуговування хороше,кімната чиста', 'Ірина Поліщук');

-- --------------------------------------------------------

--
-- Table structure for table `Connect`
--

CREATE TABLE `Connect` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `contact_page_content`
--

CREATE TABLE `contact_page_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `adres` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_page_content`
--

INSERT INTO `contact_page_content` (`id`, `title`, `text`, `adres`, `phone`, `mail`) VALUES
(1, 'Наші контакти:', 'Щось від себе', 'База відпочинку \"Машівський бір\" розташована в 3-х кілометрах від Любомля по трасі \"Ковель-Ягодин\".', '+380 097 906 4122', 'Ваш імейл');

-- --------------------------------------------------------

--
-- Table structure for table `contact_slider_content`
--

CREATE TABLE `contact_slider_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_slider_content`
--

INSERT INTO `contact_slider_content` (`id`, `photo`, `text`) VALUES
(1, 'slider1.jpg', 'Зв\'яжіться з нами');

-- --------------------------------------------------------

--
-- Table structure for table `footer_content`
--

CREATE TABLE `footer_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `header_content`
--

CREATE TABLE `header_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_list_content`
--

CREATE TABLE `hotel_list_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `about_apartments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `smal_discription` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hotel_list_content`
--

INSERT INTO `hotel_list_content` (`id`, `price`, `photo`, `title`, `about_apartments`, `smal_discription`) VALUES
(1, '₴500/доба', 'hotel_feture_1.jpg', 'Стандарт', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(2, '₴600/доба', 'hotel_feture_2.jpg', 'Поліпшений стандарт', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. \r\n', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(3, '₴700/доба', 'hotel_feture_3.jpg', 'Напівлюкс', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(4, '₴850/доба', 'hotel_feture_4.jpg', 'Люкс', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');

-- --------------------------------------------------------

--
-- Table structure for table `hotel_services_list`
--

CREATE TABLE `hotel_services_list` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acsa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hotel_services_list`
--

INSERT INTO `hotel_services_list` (`id`, `photo`, `title`, `text`, `time`, `class`, `acsa`, `view`) VALUES
(1, 'tab_img_1.jpg', 'Банкетні Зали', 'Для літнього відпочинку функціонують літні\r\nальтанки.Страви на мангалі  зможете скуштувати\r\nта приготувати самі на «Острові».\r\nНавкруги-лише спів пташок, та ставок де можна порибалити,а в лісі позбирати гриби та ягоди.\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '09:00-24:00', 'flaticon-gazebo', 'active', 'show'),
(2, 'tab_img_2.jpg', 'Ресторан', 'Кемпінг відпочинку розташований на \r\nТериторії соснового лісу.\r\nДо його складу входить двоповерховий рес-\r\nторан зі зрубу на 110 осіб.\r\nРесторан оформлений в стилі української\r\nхати-чистої,просторої з привітними хазяй-\r\nками і ароматами приготовлених смачних\r\nстрав української та європейської кухні.\r\nВ закладі Вам запропонують скуштувати\r\n м,ясо дичини.\r\nРесторан,не залишає байдужим жодного  відвідувача.Тут кожен може обрати те,що йому до душі.Зал із опудалами тварин та дерев,яними меблями,банкетні зали до 20 осіб.\r\nМи запрошуємо Вас відсвяткувати дні народження,корпоративи-серед українського\r\nколориту,в умовах домашнього затишку.\r\nПриходьте до нас поснідати,пообідати,просто\r\nпоїсти і випити за здоров,я. Ви зможете відсвяткувати весілля.\r\nУ Вашому розпорядженні простора площадка для танців.\r\nПри ресторані можна замовити спектр весільних послуг: флористика, декорування залу, оформлення виїздної церемонії, велике різноманіття смачних фуршетів та багато іншого. До Ваших послуг- студія «Весільний декор»\r\nтел.0963969547', '09:00-24:00', 'flaticon-serving-dish ', '', ''),
(3, 'tab_img_3.jpg', 'Пікнік ', 'На вулиці можна організувати пікнік\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '09:00-24:00', 'flaticon-bbq', '', ''),
(4, 'tab_img_4.jpg', 'Сауна', 'Запрошуємо Вас відвідати баню та скористатися послугами професійного банщика Івановича.Аромат березових та дубових віників ви запам,ятаєте назавжди.\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n', '09:00-24:00', 'flaticon-sauna', '', ''),
(5, 'tab_img_5.jpg', 'Дикі тварини', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '09:00-24:00', 'flaticon-pig', '', ''),
(6, 'tab_img_6.jpg', 'Чисте природа', 'Інфа про природу\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '09:00-24:00', 'flaticon-tree', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `maine_slider_content`
--

CREATE TABLE `maine_slider_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `maine_slider_content`
--

INSERT INTO `maine_slider_content` (`id`, `photo`, `title`, `text`) VALUES
(2, 'slider2.jpg', 'Готельний комплекс', 'МАШІВСЬКИЙ БІР'),
(3, 'slider3.jpg', 'Відпочинок', 'МАШІВСЬКИЙ БІР');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_11_22_124833_maine_page_header', 1),
(4, '2018_11_22_131430_hotel_list', 1),
(5, '2018_11_22_131522_hotel_secvices_list', 1),
(6, '2018_11_22_131654_commets_list', 1),
(7, '2018_11_22_131758_footer', 1),
(8, '2018_11_22_181549maine_slider_content', 1),
(9, '2018_11_22_181827_contact_slider', 1),
(10, '2018_11_22_182029_services_slider', 1),
(11, '2018_11_22_182146_rooms_slider', 1),
(12, '2018_11_22_192203_service_content', 1),
(13, '2018_11_22_192326_rooms_content', 1),
(14, '2018_11_22_193737_contact_content', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('admin@admin.com', '$2y$10$gdOMka01GVlandAgsTEPTePflZvC0cI7y4pmU6YjBwlKm1.DozQB.', '2018-11-24 22:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `precomment`
--

CREATE TABLE `precomment` (
  `id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rooms_page_content`
--

CREATE TABLE `rooms_page_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_page_content`
--

CREATE TABLE `service_page_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slider_rooms_content`
--

CREATE TABLE `slider_rooms_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slider_rooms_content`
--

INSERT INTO `slider_rooms_content` (`id`, `photo`, `text`) VALUES
(1, 'slider3.jpg', 'Кімнати нашого готелю');

-- --------------------------------------------------------

--
-- Table structure for table `slider_services_content`
--

CREATE TABLE `slider_services_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', NULL, '$2y$10$N/x.x9YGMOdi2eVd4Q7uUuNv4jAts/nMcPsd9gP5ReNgaKWXutqLi', NULL, '2018-11-24 11:22:54', '2018-11-24 11:22:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment_list_content`
--
ALTER TABLE `comment_list_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Connect`
--
ALTER TABLE `Connect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_page_content`
--
ALTER TABLE `contact_page_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_slider_content`
--
ALTER TABLE `contact_slider_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footer_content`
--
ALTER TABLE `footer_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header_content`
--
ALTER TABLE `header_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_list_content`
--
ALTER TABLE `hotel_list_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_services_list`
--
ALTER TABLE `hotel_services_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maine_slider_content`
--
ALTER TABLE `maine_slider_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `precomment`
--
ALTER TABLE `precomment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms_page_content`
--
ALTER TABLE `rooms_page_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_page_content`
--
ALTER TABLE `service_page_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_rooms_content`
--
ALTER TABLE `slider_rooms_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_services_content`
--
ALTER TABLE `slider_services_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment_list_content`
--
ALTER TABLE `comment_list_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Connect`
--
ALTER TABLE `Connect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_page_content`
--
ALTER TABLE `contact_page_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_slider_content`
--
ALTER TABLE `contact_slider_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `footer_content`
--
ALTER TABLE `footer_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `header_content`
--
ALTER TABLE `header_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_list_content`
--
ALTER TABLE `hotel_list_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hotel_services_list`
--
ALTER TABLE `hotel_services_list`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `maine_slider_content`
--
ALTER TABLE `maine_slider_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `precomment`
--
ALTER TABLE `precomment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms_page_content`
--
ALTER TABLE `rooms_page_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_page_content`
--
ALTER TABLE `service_page_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `slider_rooms_content`
--
ALTER TABLE `slider_rooms_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider_services_content`
--
ALTER TABLE `slider_services_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
