@extends('layouts.publick.site')

@section('head')
    @include('layouts.publick.header')
@endsection
@section('slider')
    @include('layouts.sliders.heads')
@endsection
@section('content')
    @include('layouts.publick.content')
@endsection
@section('footer')
    @include('layouts.publick.footer')
@endsection