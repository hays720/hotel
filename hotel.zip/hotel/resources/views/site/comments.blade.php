@extends('layouts.publick.site')

@section('head')
    @include('layouts.publick.header')
@endsection
@section('slider')
    @include('layouts.sliders.contact_slider')
@endsection
@section('content')
    <div id="fh5co-contact-section">
        <div class="row">
            <div class="col-md-6">
                <div id="map" class="fh5co-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m11!1m3!1d1648.6580725000308!2d24.089880319571943!3d51.20365467962384!2m2!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47247347f5dbe8db%3A0x6e02dfde3420dbbe!2sMashivs%CA%B9kyy+Bir!5e1!3m2!1sru!2sua!4v1542834164417" width="100%" height="700" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-md-6">
                <div class="col-md-12">
                       <h2>Залиште свій коментарь</h2>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        
                            <form method="post" action="comments">
                                <div class="col-md-6">
                                    
                           
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" placeholder="Ваше ім'я">
                            </div>
                        </div>
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea name="comment" class="form-control" id="" cols="30" rows="7" placeholder="Ваш коментар"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="submit" value="Відправити" class="btn btn-primary">
                            </div>
                        </div>
                                {{ csrf_field() }}
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('footer')
    @include('layouts.publick.footer')
@endsection