@extends('layouts.publick.site')

@section('head')
    @include('layouts.publick.header')
@endsection
@section('slider')
    @include('layouts.sliders.rooms_slider')
@endsection
@section('content')
    @include('layouts.publick.rooms')
@endsection
@section('footer')
    @include('layouts.publick.footer')
@endsection