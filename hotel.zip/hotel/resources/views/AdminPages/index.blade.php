@extends('layouts.Admin.site')

@section('sidebar')
    @include('layouts.Admin.sidebar')
@endsection

@section('content')
    @include('layouts.Admin.maine')
@endsection
