@extends('layouts.Admin.site')

@section('sidebar')
    @include('layouts.Admin.sidebar')
@endsection

@section('content')
    <div class="row">
        <div class="col-6">
            <h2>Слайдер</h2>
            <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th class="th-sm">Дії
                    </th>
                    <th class="th-sm">Заголовок
                    </th>
                    <th class="th-sm">Текст
                    </th>
                    <th class="th-sm">Фото
                    </th>

                </tr>
                </thead>
                <tbody>
                @foreach($slider as $value)
                    <tr>
                        <td>
                            <a href="?slider_delete={{ $value->id }}"><button type="button" class="btn btn-danger">Видалити</button></a>
                        </td>

                        <td>{{ $value->title }}</td>
                        <td>{{ $value->text }}</td>
                        <td>{{ $value->photo }}</td>

                    </tr>
                @endforeach
                </tbody>
                <tfoot>
                <tr>
                    <th>Дії
                    </th>
                    <th>Заголовок
                    </th>
                    <th>Текст
                    </th>
                    <th>Фото
                    </th>
                </tr>
                </tfoot>
            </table>
        </div>
            <div class="col-6">
        <h2>Додати слайдер</h2>
            <form action="/admin/maine">
                <div class="form-group">
                    <label for="formGroupExampleInput2">Заголовок</label>
                    <input name="slider_title" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Заголовок слайдера">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput2">Текст</label>
                    <input name="slider_disc" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Текст слайдера">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput">Фото</label>
                    <input name="slider_photo" type="file">
                </div>
                <button type="button" class="btn btn-success">Додати</button>
                {{ csrf_field() }}
            </form>
            </div>
    </div>

    <div class="row">
    <div class="col-6">
        <h2>Готелі</h2>
        <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th class="th-sm">Назва
                </th>
                <th class="th-sm">Ціна
                </th>
                <th class="th-sm">Опис
                </th>
                <th class="th-sm">Міні опис
                </th>
                <th class="th-sm">Фото
                </th>
            </tr>
            </thead>
            <tbody>
            @foreach($room as $value)
                <tr>
                    <td>{{ $value->title }}</td>
                    <td>{{ $value->price }}</td>
                    <td>{{ $value->about_apartments}}</td>
                    <td>{{ $value->	smal_discription}}</td>
                    <td>{{ $value->photo }}</td>

                </tr>
            @endforeach

            </tbody>
            <tfoot>
            <tr>
                <th>Назва
                </th>
                <th>Ціна
                </th>
                <th>Опис
                </th>
                <th>Міні опис
                </th>
                <th>Фото
                </th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="col-6">
        <h2>Змінити готель</h2>
        <form action="/admin/maine">
            <div class="form-group">
                <label for="exampleFormControlSelect1">Виберіть назву</label>
                <select name="sel_h" class="form-control" id="exampleFormControlSelect1">
                    @foreach($room as $value)
                        <option>{{ $value->title }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Нова назва</label>
                <input name="hotel_title" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Нова ціна</label>
                <input name="hotel_price" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Новий опис</label>
                <input name="hotel_disc" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Новий міні опис</label>
                <input name="hotel_minidisc" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput">Нове фото</label>
                <input name="hotel_photo" type="file">
            </div>
            <button type="button" class="btn btn-success">Змінити</button>
            {{ csrf_field() }}
        </form>
    </div>
</div>
    <div class="row">
        <div class="col-6">
            <h2>Сервіси</h2>
            <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th class="th-sm">Заголовок
                    </th>
                    <th class="th-sm">Текст
                    </th>
                    <th class="th-sm">Часи роботи
                    </th>
                    <th class="th-sm">Фото
                    </th>

                </tr>
                </thead>
                <tbody>
                @foreach($ser as $value)
                    <tr>
                        <td>{{ $value->title }}</td>
                        <td>{{ $value->text }}</td>
                        <td>{{ $value->time }}</td>
                        <td>{{ $value->photo }}</td>

                    </tr>
                @endforeach
                </tbody>
                <tfoot>
                <tr>
                    <th>Заголовок
                    </th>
                    <th>Текст
                    </th>
                    <th>Часи роботи
                    </th>
                    <th>Фото
                    </th>
                </tr>
                </tfoot>
            </table>
        </div>
        <div class="col-6">
            <h2>Змінити сервіси</h2>
            <form>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Виберіть назву</label>
                    <select class="form-control" id="exampleFormControlSelect1">
                        @foreach($ser as $value)
                            <option>{{ $value->title }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput2">Нова назва</label>
                    <input name="slider_title" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput2">Новий опис</label>
                    <input name="slider_title" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput2">Нові часи роботи</label>
                    <input name="slider_disc" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
                </div>
                <div class="form-group">
                    <label for="formGroupExampleInput">Нове фото</label>
                    <input name="slider_photo" type="file">
                </div>
                <button type="button" class="btn btn-success">Змінити</button>
                {{ csrf_field() }}
            </form>
        </div>


    </div>
    <div class="row">
        <div class="row">
            <div class="col-6">
                <h2>Коментарі</h2>
                <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th class="th-sm">Дії
                        </th>
                        <th class="th-sm">Ім'я
                        </th>
                        <th class="th-sm">Коментарь
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($comment as $value)
                        <tr>
                            <td>
                                <p></p>
                                <a href="?com_delete={{ $value->id }}"><button type="button" class="btn btn-danger">Видалити</button></a>
                            </td>
                            <td>{{ $value->name }}</td>
                            <td>{{ $value->comment }}</td>
                        </tr>
                    @endforeach

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Дії
                        </th>
                        <th>Ім'я
                        </th>
                        <th>Коментарь
                        </th>
                    </tr>
                    </tfoot>
                </table>
        </div>


    </div>





@endsection
