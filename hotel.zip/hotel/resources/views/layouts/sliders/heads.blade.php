<aside id="fh5co-hero" class="js-fullheight">
    <div class="flexslider js-fullheight">
        <ul class="slides">
@foreach($slide as $value)
    <li style="background-image: url({{asset('hotel/images/slider/'.$value->photo.'')}}">
        <div class="overlay-gradient"></div>
        <div class="container">
            <div class="col-md-12 col-md-offset-0 text-center slider-text">
                <div class="slider-text-inner js-fullheight">
                    <div class="desc">
                        <p><span>-{{ $value->title }}</span></p>
                        <h2>{{ $value->text }}</h2>
                        <p>
                            <a href="contact" class="btn btn-primary btn-lg">Наші Контакти</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </li>
    @endforeach
        </ul>
    </div>
</aside>