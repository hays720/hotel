<div class="row">
    <div class="col-5">
        <h2>Тут будуть нові коментарі: </h2>
        <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th class="th-sm">Дії
                </th>
                <th class="th-sm">Ім'я
                </th>
                <th class="th-sm">Коментар
                </th>

            </tr>
            </thead>
            <tbody>
            @foreach($com as $value)
            <tr>

                <td>
                    <a href="?add={{ $value->id }}"><button type="button" class="btn btn-success">Змінити</button></a>
                    <p></p>
                    <a href="?delete={{ $value->id }}"><button type="button" class="btn btn-danger">Видалити</button></a>
                </td>

                <td>{{ $value->name }}</td>
                <td>{{ $value->comment }}</td>

            </tr>
                @endforeach
            </tbody>
            <tfoot>
            <tr>
                <th >Дії
                </th>
                <th >Ім'я
                </th>
                <th >Коментар
                </th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="col-7">
        <h2>Вам залишили повідомлення: </h2>
        <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th class="th-sm">Дії
                </th>
                <th class="th-sm">Ім'я
                </th>
                <th class="th-sm">Email/Телефон
                </th>
                <th class="th-sm">Повідомлення
                </th>
            </tr>
            </thead>
            <tbody>
            @foreach($con as $value)
                <tr>
                    <td>
                        <a href="?dielete={{ $value->id }}"><button type="button" class="btn btn-danger">Видалити</button></a>
                    </td>
                    <td>{{ $value->name }}</td>
                    <td>{{ $value->email }}</td>
                    <td>{{ $value->text }}</td>
                </tr>
                @endforeach

            </tbody>
            <tfoot>
            <tr>
                <th >Дії
                </th><th >Ім'я
                </th>
                <th >Email/Телефон
                </th>
                <th >Коментар
                </th>
            </tr>
            </tfoot>
        </table>
    </div>
</div>