<div id="fh5co-hotel-section">
    <div class="container">
        <div class="row">
            @foreach($content as $value)
                <div class="col-md-4">
                    <div class="hotel-content ">
                        <div class="hotel-grid" style="background-image: url({{asset('hotel/images/HotelList/'.$value->photo.'')}});)">
                            <div class="price"><small>Ціна:</small><span>{{$value->price}}</span></div>
                            <a class="book-now text-center" href="#"><i class="ti-calendar"></i>Переглянути номер</a>
                        </div>
                        <div class="desc qewr">
                            <h3><a href="#">{{ $value->title }}</a></h3>
                            <p>{{ $value->smal_discription }}</p>
                        </div>
                    </div>
                </div>
                @endforeach



        </div>
    </div>
</div>