
<div id="featured-hotel" class="fh5co-bg-color">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>НАШІ ГОТЕЛІ</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="feature-full-1col">
                <div class="image" style="background-image: url({{asset('hotel/images/HotelList/'.$r_photo[0].'')}});">
                    <div class="descrip text-center">
                        <p><small>Ціна:</small><span>{{ $r_price[0] }}</span></p>
                    </div>
                </div>
                <div class="desc">
                    <h3>{{$r_title[0]}}</h3>
                    <p>{{$r_disk[0]}}</p>
                    <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                </div>
            </div>

            <div class="feature-full-2col">
                <div class="f-hotel">
                    <div class="image" style="background-image: url({{asset('hotel/images/HotelList/'.$r_photo[1].'')}})">
                        <div class="descrip text-center">
                            <p><small>Ціна:</small><span>{{ $r_price[1] }}</span></p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3>{{$r_title[1]}}</h3>
                        <p>{{$r_disk[1]}}</p>
                        <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                    </div>
                </div>
                <div class="f-hotel">
                    <div class="image" style="background-image: url({{asset('hotel/images/HotelList/'.$r_photo[2].'')}})">
                        <div class="descrip text-center">
                            <p><small>Ціна:</small><span>{{ $r_price[2] }}</span></p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3>{{$r_title[2]}}</h3>
                        <p>{{$r_disk[2]}} </p>
                        <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                    </div>
                </div>
            </div>
            <div class="feature-full-1col">
                <div class="desc">
                    <h3>{{$r_title[3]}}</h3>
                    <p>{{$r_disk[3]}}</p>
                    <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                </div>
                <div class="image" style="background-image: url({{asset('hotel/images/HotelList/'.$r_photo[3].'')}})">
                    <div class="descrip text-center">
                        <p><small>Ціна:</small><span>{{ $r_price[3] }}</span></p>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<div id="hotel-facilities">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>НАШІ ПЕРЕВАГИ</h2>
                </div>
            </div>
        </div>



        <div id="tabs">
            <nav class="tabs-nav">
                @foreach($service as $value)
                <a href="#" class="{{$value->acsa}}"  data-tab="tab{{$value->id}}">
                    <i class=" {{$value->class}} icon"></i>
                    <span>{{$value->title}}</span>
                </a>
                @endforeach

            </nav>
            <div class="tab-content-container">
                @foreach($service as $value)
                    <div class="tab-content {{$value->acsa}} {{ $value->view }}" data-tab-content="tab{{$value->id}}">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <img src="{{asset('hotel/images/TabImages/'.$value->photo.'')}}" class="img-responsive" alt="Image">
                                </div>
                                <div class="col-md-6">
                                    <h3 class="heading">{{ $value->title }}</h3>
                                    <p>{{$value->text}}</p>
                                    <p class="service-hour">
                                        <span>Графік роботи</span>
                                        <strong>{{$value->time}}</strong>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

            </div>
        </div>
    </div>
</div>

<div id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>ВІДГУКИ НАШИХ КЛІЄНТІВ</h2>
                </div>
            </div>
        </div>

        <div class="row">
            @foreach($comment as $value)
                    <div class="col-md-4">
                        <div class="testimony">
                            <blockquote>
                                &ldquo;{{ $value->comment }}&rdquo;
                            </blockquote>
                            <p class="author"><cite>{{ $value->name }}</cite></p>
                        </div>
                    </div>
                    @endforeach

        </div>
        {{ $comment->links() }}
    </div>
</div>