<div id="fh5co-services-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-location-pin"></i></span>
                    <div class="desc">
                        <h3>Accessible Location</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-alarm-clock"></i></span>
                    <div class="desc">
                        <h3>Open 24/7</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-calendar"></i></span>
                    <div class="desc">
                        <h3>Reservation</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-user"></i></span>
                    <div class="desc">
                        <h3>Friendly Staff</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-signal"></i></span>
                    <div class="desc">
                        <h3>Free Wifi</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="services">
                    <span><i class="ti-location-pin"></i></span>
                    <div class="desc">
                        <h3>Accessible Location</h3>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>