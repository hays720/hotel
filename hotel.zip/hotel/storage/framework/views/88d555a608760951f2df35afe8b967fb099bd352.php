<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <title>Luxe &mdash; 100% Free Fully Responsive HTML5 Template by FREEHTML5.co</title>
    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <link rel="shortcut icon" href="<?php echo e(asset('hotel/logo.cpt')); ?> ">
    <!-- <link href='https://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700italic,900,700,900italic' rel='stylesheet' type='text/css'> -->

    <!-- Stylesheets -->
    <!-- Dropdown Menu -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/superfish.css')); ?>">
    <!-- Owl Slider -->
    <!-- <link rel="stylesheet" href="css/owl.carousel.css"> -->
    <!-- <link rel="stylesheet" href="css/owl.theme.default.min.css"> -->
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/bootstrap-datepicker.min.css')); ?>">
    <!-- CS Select -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/cs-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/cs-skin-border.css')); ?>">

    <!-- Themify Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/themify-icons.css')); ?>">
    <!-- Flat Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/flaticon.css')); ?>">
    <!-- Icomoon -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/icomoon.css')); ?>">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/flexslider.css')); ?>">

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('hotel/css/style.css')); ?>">

    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('hotel/js/modernizr-2.6.2.min.js')); ?>"></script>

</head>
<body>
<div id="fh5co-wrapper">
    <div id="fh5co-page">

        <?php echo $__env->yieldContent('head'); ?>
<?php echo $__env->yieldContent('slider'); ?>
        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldContent('footer'); ?>

    </div>
    <!-- END fh5co-page -->

</div>
<!-- END fh5co-wrapper -->

<!-- Javascripts -->
<script src="<?php echo e(asset('hotel/js/jquery-2.1.4.min.js')); ?>"></script>
<!-- Dropdown Menu -->
<script src="<?php echo e(asset('hotel/js/hoverIntent.js')); ?>"></script>
<script src="<?php echo e(asset('hotel/js/superfish.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('hotel/js/bootstrap.min.js')); ?>"></script>
<!-- Waypoints -->
<script src="<?php echo e(asset('hotel/js/jquery.waypoints.min.js')); ?>"></script>
<!-- Counters -->
<script src="<?php echo e(asset('hotel/js/jquery.countTo.js')); ?>"></script>
<!-- Stellar Parallax -->
<script src="<?php echo e(asset('hotel/js/jquery.stellar.min.js')); ?>"></script>
<!-- Owl Slider -->
<!-- // <script src="js/owl.carousel.min.js"></script> -->
<!-- Date Picker -->
<script src="<?php echo e(asset('hotel/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- CS Select -->
<script src="<?php echo e(asset('hotel/js/classie.js')); ?>"></script>
<script src="<?php echo e(asset('hotel/js/selectFx.js')); ?>"></script>
<!-- Flexslider -->
<script src="<?php echo e(asset('hotel/js/jquery.flexslider-min.js')); ?>"></script>

<script src="<?php echo e(asset('hotel/js/custom.js')); ?>"></script>

<script src="https://www.google.com/maps/embed?pb=!1m17!1m11!1m3!1d1648.6580725000308!2d24.089880319571943!3d51.20365467962384!2m2!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47247347f5dbe8db%3A0x6e02dfde3420dbbe!2sMashivs%CA%B9kyy+Bir!5e1!3m2!1sru!2sua!4v1542834164417" ></script>

    <script src="<?php echo e(asset('hotel/js/google_map.js')); ?>"></script>

</body>
</html>