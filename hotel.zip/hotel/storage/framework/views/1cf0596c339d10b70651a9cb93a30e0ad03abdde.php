<div id="fh5co-hotel-section">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="hotel-content ">
                        <div class="hotel-grid" style="background-image: url(<?php echo e(asset('hotel/images/HotelList/'.$value->photo.'')); ?>);)">
                            <div class="price"><small>Ціна:</small><span><?php echo e($value->price); ?></span></div>
                            <a class="book-now text-center" href="#"><i class="ti-calendar"></i>Переглянути номер</a>
                        </div>
                        <div class="desc qewr">
                            <h3><a href="#"><?php echo e($value->title); ?></a></h3>
                            <p><?php echo e($value->smal_discription); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
</div>