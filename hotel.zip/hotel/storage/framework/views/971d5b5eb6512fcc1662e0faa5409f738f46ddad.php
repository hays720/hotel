<aside id="fh5co-hero" class="js-fullheight">
    <div class="flexslider js-fullheight">
        <ul class="slides">
<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="background-image: url(<?php echo e(asset('hotel/images/slider/'.$value->photo.'')); ?>">
        <div class="overlay-gradient"></div>
        <div class="container">
            <div class="col-md-12 col-md-offset-0 text-center slider-text">
                <div class="slider-text-inner js-fullheight">
                    <div class="desc">
                        <p><span>-<?php echo e($value->title); ?></span></p>
                        <h2><?php echo e($value->text); ?></h2>
                        <p>
                            <a href="contact" class="btn btn-primary btn-lg">Наші Контакти</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</aside>