<div id="fh5co-contact-section">
        <div class="row">
            <div class="col-md-6">
                <div id="map" class="fh5co-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m11!1m3!1d1648.6580725000308!2d24.089880319571943!3d51.20365467962384!2m2!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47247347f5dbe8db%3A0x6e02dfde3420dbbe!2sMashivs%CA%B9kyy+Bir!5e1!3m2!1sru!2sua!4v1542834164417" width="100%" height="700" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-md-6">
                <div class="col-md-12">
                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3><?php echo e($value->title); ?></h3>
                        <p><?php echo e($value->text); ?></p>
                        <ul class="contact-info">
                            <li><i class="ti-map"></i><?php echo e($value->adres); ?></li>
                            <li><i class="ti-mobile"></i><?php echo e($value->phone); ?></li>
                            <li><i class="ti-envelope"></i><a href="#"><?php echo e($value->mail); ?></a></li>
                        </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <form method="post" action="contact">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="email" class="form-control" placeholder="Email/Телефон">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea name="text" class="form-control"  id="" cols="30" rows="7" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="submit" value="Send Message" class="btn btn-primary">
                                </div>
                            </div>
                            <?php echo e(csrf_field()); ?>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>