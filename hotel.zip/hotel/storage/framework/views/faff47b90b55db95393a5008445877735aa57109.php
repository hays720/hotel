<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.Admin.maine', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Admin.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>