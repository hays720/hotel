<div id="fh5co-header">
    <header id="fh5co-header-section">
        <div class="container">
            <div class="nav-header">
                <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
                <h1 id="fh5co-logo"><a href=" /hotel/public/ ">МАШІВСЬКИЙ БІР
                    </a></h1>
                <nav id="fh5co-menu-wrap" role="navigation">
                    <ul class="sf-menu" id="fh5co-primary-menu">
                        <li><a href=" /hotel/public/ ">Home</a></li>
                        <li>
                            <a href="rooms" class="fh5

                            co-sub-ddown">Номери</a>
                            <ul class="fh5co-sub-menu">
                                <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="#"><?php echo e($value->title); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <li><a href="services">Переваги</a></li>
                        <li><a href="contact">Контакти</a></li>
                        <li><a href="comments">Залишити відгук</a></li>

                    </ul>
                </nav>
            </div>
        </div>
    </header>

</div>
<!-- end:fh5co-header -->