<div class="row">
    <div class="col-5">
        <h2>Тут будуть нові коментарі: </h2>
        <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th class="th-sm">Дії
                </th>
                <th class="th-sm">Ім'я
                </th>
                <th class="th-sm">Коментар
                </th>

            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td>
                    <a href="?add=<?php echo e($value->id); ?>"><button type="button" class="btn btn-success">Змінити</button></a>
                    <p></p>
                    <a href="?delete=<?php echo e($value->id); ?>"><button type="button" class="btn btn-danger">Видалити</button></a>
                </td>

                <td><?php echo e($value->name); ?></td>
                <td><?php echo e($value->comment); ?></td>

            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <th >Дії
                </th>
                <th >Ім'я
                </th>
                <th >Коментар
                </th>
            </tr>
            </tfoot>
        </table>
    </div>
    <div class="col-7">
        <h2>Вам залишили повідомлення: </h2>
        <table id="dtVerticalScrollExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th class="th-sm">Дії
                </th>
                <th class="th-sm">Ім'я
                </th>
                <th class="th-sm">Email/Телефон
                </th>
                <th class="th-sm">Повідомлення
                </th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $con; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="?dielete=<?php echo e($value->id); ?>"><button type="button" class="btn btn-danger">Видалити</button></a>
                    </td>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->text); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot>
            <tr>
                <th >Дії
                </th><th >Ім'я
                </th>
                <th >Email/Телефон
                </th>
                <th >Коментар
                </th>
            </tr>
            </tfoot>
        </table>
    </div>
</div>