<footer id="footer" class="fh5co-bg-color">
    <div class="container">
        <div class="row">

            <div class="col-md-6">
                <div class="row">

                    <div class="col-md-3">
                        <h3>Про нас</h3>
                        <ul class="link">
                            <li><a href="#">Ресторани</a></li>
                            <li><a href="#">Готелі</a></li>
                            <li><a href="#">Паркінг</a></li>
                            <li><a href="#">Територія</a></li>
                            <li><a href="#">Дикі тварини</a></li>
                            <li><a href="#">Огород</a></li>

                        </ul>
                    </div>
                    <div class="col-md-3">
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="copyright">
                </div>
            </div>
            <div class="col-md-3">
                <ul class="social-icons">
                    <li>
                        <a href="#"><i class="icon-twitter-with-circle"></i></a>
                        <a href="#"><i class="icon-facebook-with-circle"></i></a>
                        <a href="#"><i class="icon-instagram-with-circle"></i></a>
                        <a href="#"><i class="icon-linkedin-with-circle"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>