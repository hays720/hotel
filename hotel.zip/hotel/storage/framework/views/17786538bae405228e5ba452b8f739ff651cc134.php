
<div id="featured-hotel" class="fh5co-bg-color">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>НАШІ ГОТЕЛІ</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="feature-full-1col">
                <div class="image" style="background-image: url(<?php echo e(asset('hotel/images/HotelList/'.$r_photo[0].'')); ?>);">
                    <div class="descrip text-center">
                        <p><small>Ціна:</small><span><?php echo e($r_price[0]); ?></span></p>
                    </div>
                </div>
                <div class="desc">
                    <h3><?php echo e($r_title[0]); ?></h3>
                    <p><?php echo e($r_disk[0]); ?></p>
                    <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                </div>
            </div>

            <div class="feature-full-2col">
                <div class="f-hotel">
                    <div class="image" style="background-image: url(<?php echo e(asset('hotel/images/HotelList/'.$r_photo[1].'')); ?>)">
                        <div class="descrip text-center">
                            <p><small>Ціна:</small><span><?php echo e($r_price[1]); ?></span></p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3><?php echo e($r_title[1]); ?></h3>
                        <p><?php echo e($r_disk[1]); ?></p>
                        <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                    </div>
                </div>
                <div class="f-hotel">
                    <div class="image" style="background-image: url(<?php echo e(asset('hotel/images/HotelList/'.$r_photo[2].'')); ?>)">
                        <div class="descrip text-center">
                            <p><small>Ціна:</small><span><?php echo e($r_price[2]); ?></span></p>
                        </div>
                    </div>
                    <div class="desc">
                        <h3><?php echo e($r_title[2]); ?></h3>
                        <p><?php echo e($r_disk[2]); ?> </p>
                        <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                    </div>
                </div>
            </div>
            <div class="feature-full-1col">
                <div class="desc">
                    <h3><?php echo e($r_title[3]); ?></h3>
                    <p><?php echo e($r_disk[3]); ?></p>
                    <p><a href="#" class="btn btn-primary btn-luxe-primary">Переглянути номер<i class="ti-angle-right"></i></a></p>
                </div>
                <div class="image" style="background-image: url(<?php echo e(asset('hotel/images/HotelList/'.$r_photo[3].'')); ?>)">
                    <div class="descrip text-center">
                        <p><small>Ціна:</small><span><?php echo e($r_price[3]); ?></span></p>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<div id="hotel-facilities">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>НАШІ ПЕРЕВАГИ</h2>
                </div>
            </div>
        </div>



        <div id="tabs">
            <nav class="tabs-nav">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#" class="<?php echo e($value->acsa); ?>"  data-tab="tab<?php echo e($value->id); ?>">
                    <i class=" <?php echo e($value->class); ?> icon"></i>
                    <span><?php echo e($value->title); ?></span>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </nav>
            <div class="tab-content-container">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-content <?php echo e($value->acsa); ?> <?php echo e($value->view); ?>" data-tab-content="tab<?php echo e($value->id); ?>">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <img src="<?php echo e(asset('hotel/images/TabImages/'.$value->photo.'')); ?>" class="img-responsive" alt="Image">
                                </div>
                                <div class="col-md-6">
                                    <h3 class="heading"><?php echo e($value->title); ?></h3>
                                    <p><?php echo e($value->text); ?></p>
                                    <p class="service-hour">
                                        <span>Графік роботи</span>
                                        <strong><?php echo e($value->time); ?></strong>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>

<div id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>ВІДГУКИ НАШИХ КЛІЄНТІВ</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="testimony">
                            <blockquote>
                                &ldquo;<?php echo e($value->comment); ?>&rdquo;
                            </blockquote>
                            <p class="author"><cite><?php echo e($value->name); ?></cite></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php echo e($comment->links()); ?>

    </div>
</div>