<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware'=>'web'],function(){
    Route::get('/',['uses'=>'MainePageController@index', 'as'=>'home']);
    Route::match(['get','post'],'/contact',['uses'=>'ContactController@index', 'as'=>'contact']);
    Route::get('/rooms',['uses'=>'RoomsController@index', 'as'=>'rooms']);
    Route::get('/services',['uses'=>'ServicesController@index', 'as'=>'services']);
    Route::match(['get','post'],'/comments',['uses'=>'CommentsPageController@index', 'as'=>'comments']);
    Route::auth();
});
//admin
Route::group(['prefix'=>'admin','middleware'=>'auth'],function(){
    //admin
    Route::get('/',['uses'=>'MaineAdminPage@index']);
//    AdminPages.index
    //admin/maine
    Route::match(['get','post'],'/maine',['uses'=>'AdminMainContentController@index']);

    Route::group(['prefix'=>'rooms'],function(){
        Route::get('/',['uses'=>'AdminRoomsPage@execute','as'=>'maine']);

        Route::post('/slider',['uses'=>'AdminRoomsPage@update']);

        Route::post('/content',['uses'=>'AdminRoomsPage@update']);

    });
    Route::group(['prefix'=>'services'],function(){
        Route::get('/',['uses'=>'AdminServicesPage@execute','as'=>'maine']);

        Route::post('/slider',['uses'=>'AdminServicesPage@update']);

        Route::post('/content',['uses'=>'AdminServicesPage@update']);

    });

    Route::group(['prefix'=>'contacts'],function(){
        Route::get('/',['uses'=>'AdminServicesPage@execute','as'=>'maine']);

        Route::post('/slider',['uses'=>'AdminContactsPage@update']);

        Route::post('/content',['uses'=>'AdminContactsPage@update']);

    });
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
