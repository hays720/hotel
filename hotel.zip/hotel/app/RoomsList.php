<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoomsList extends Model
{
    protected $table = 'hotel_list_content';
}
