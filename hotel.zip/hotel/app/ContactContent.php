<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContactContent extends Model
{
    protected $table = 'contact_page_content';
}
