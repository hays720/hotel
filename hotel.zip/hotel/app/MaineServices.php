<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaineServices extends Model
{
    protected $table = 'hotel_services_list';
}
