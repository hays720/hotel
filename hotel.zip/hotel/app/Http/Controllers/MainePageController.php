<?php

namespace App\Http\Controllers;

use App\MaineSlider;
use App\RoomsList;
use App\MaineServices;
use App\CommentsList;



class MainePageController extends Controller
{
    public function Index(){
        $slider = MaineSlider::all();
        $rooms = RoomsList::all();
        $services = MaineServices::all();
        $comments = CommentsList::paginate(3);

        $rooms_photo = array();
        $rooms_price = array();
        $rooms_title = array();
        $rooms_disk = array();
        $count = 0;

        foreach ($rooms as $value){
            array_push($rooms_photo,$value->photo);
            array_push($rooms_price,$value->price);
            array_push($rooms_title,$value->title);
            array_push($rooms_disk,$value->about_apartments);
            $count++;
        }
        return view('site.index',[
             'slide'=> $slider,
             'r_photo'=>$rooms_photo,
             'r_price'=>$rooms_price,
             'r_title'=>$rooms_title,
             'r_disk'=>$rooms_disk,
             'service'=>$services,
             'comment'=>$comments,
             'header'=>$rooms
        ]);
    }
}
//{{ $page->links() }}