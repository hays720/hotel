<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\PreCom;
use App\con;
use Illuminate\Support\Facades\DB;
use App\CommentsList;

class MaineAdminPage extends Controller
{

    public function index(Request $request){


        $Com = PreCom::all();
        $contact = con::all();

        $add = $request->get('add');
        $delete = $request->get('delete');
        $dele= $request->get('dielete');

        if (isset($add)){
            $z = DB::table('precomment')->where('id',$add)->get();
            $arr =  array(
                'name'=>$z[0]->name,
                'comment'=>$z[0]->comment
            );

            DB::table('comment_list_content')->insert($arr);
            DB::table('precomment')->where('id',$add)->delete();
        }
        if (isset($delete)){
            DB::table('precomment')->where('id',$delete)->delete();
        }
        if (isset($dele)){
            DB::table('Connect')->where('id',$dele)->delete();
        }


        return view('AdminPages.index',[
            'com'=>$Com,
            'con'=>$contact
        ]);
    }
}
