<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ContactContent;
use App\SliderContact;
use App\RoomsList;
use Illuminate\Support\Facades\DB;


class ContactController extends Controller
{
    public function index(Request $request){

        $content = ContactContent::all();
        $slider = SliderContact::all();
        $header = RoomsList::all('title');


        $name = $request->input('name');
        $email = $request->input('email');
        $text = $request->input('text');
        if (isset($name) && isset($email) && isset($text)){

                $Add = array(
                    'name' => $name,
                    'email' => $email,
                    'text' => $text
                );

        DB::table('Connect')->insert($Add);
    }



        return view('site.contact',[
            'slider' => $slider,
            'content' => $content,
            'header'=>$header
            ]);
    }
}
