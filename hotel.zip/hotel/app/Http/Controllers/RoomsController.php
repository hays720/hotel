<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SliderRooms;
use App\RoomsList;
class RoomsController extends Controller
{
    public function index(){

        $slider = SliderRooms::all();
        $content = RoomsList::all();

        return view('site.rooms',[
            'slider'=>$slider,
            'content'=>$content,
            'header'=>$content
        ]);
    }
}
