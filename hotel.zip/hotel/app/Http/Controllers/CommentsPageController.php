<?php

namespace App\Http\Controllers;

use App\RoomsList;
use App\SliderContact;
use App\PreCom;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class CommentsPageController extends Controller
{
    public function index(Request $request){
        $name = $request->input('name');
        $text = $request->input('comment');

        if(isset($name) && isset($text)){
            $AddArr = array(
                'name' =>$name,
                'comment'=>$text
            );
            DB::table('precomment')->insert($AddArr);
        }

        $slider = SliderContact::all();
        $header = RoomsList::all('title');

        return view('site.comments'
            ,[
            'header'=>$header,
            'slider'=>$slider
        ]
        );
    }
}
