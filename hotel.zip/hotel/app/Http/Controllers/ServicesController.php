<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RoomsList;

class ServicesController extends Controller
{
    public function index(){

        $header = RoomsList::all('title');

        return view('site.services',[
            'header' =>$header
            ]);
    }
}
