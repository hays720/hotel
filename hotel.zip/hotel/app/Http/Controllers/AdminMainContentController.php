<?php

namespace App\Http\Controllers;

use function foo\func;
use Illuminate\Http\Request;
use App\CommentsList;
use App\MaineServices;
use App\MaineSlider;
use App\RoomsList;
use Illuminate\Support\Facades\DB;

class AdminMainContentController extends Controller
{
        public function index(Request $request){

            $com = CommentsList::all();
            $room = RoomsList::all();
            $slider = MaineSlider::all();
            $ser = MaineServices::all();

            $delete_slider = $request->get('slider_delete');
            $delete_comment = $request->get('com_delete');

            $slider_title = $request->input('slider_title');
            $slider_disc = $request->input('slider_disc');
            $slider_photo = $request->input('slider_photo');



            function delete($id, $table)
            {
                return DB::table($table)->where('id', $id)->delete();
            };
            function update($table,$colum, $id, $arr){
                return DB::table($table)->where($colum, $id)->update($arr);
            };
            function insert($table,$arr){
                return DB::table($table)->insert($arr);
            }

            if (isset($delete_slider)){
                $table = 'maine_slider_content';
                delete($delete_slider,$table);
            }
            elseif(isset($delete_comment)){
                $table = 'comment_list_content';
                delete($delete_comment,$table);
            };
            if (isset($slider_title) && isset($slider_title) && isset($slider_title)){
                $arr = array(
                    'photo'=>$slider_photo,
                    'title'=>$slider_title,
                    'text'=>$slider_disc
                );
                insert('maine_slider_content',$arr);
            }
            $hotel_select = $request->input('sel_h');
            $hotel_title = $request->input('hotel_title');
            $hotel_price = $request->input('hotel_price');
            $hotel_disc = $request->input('hotel_disc');
            $hotel_minidisc = $request->input('hotel_minidisc');
            $hotel_photo = $request->input('hotel_photo');

            if (isset($hotel_select) && isset($hotel_select) && isset($hotel_select) && isset($hotel_select) && isset($hotel_select)){
                $arr = array(
                    'price'=>$hotel_price,
                    'photo'=>$hotel_photo,
                    'title'=>$hotel_title,
                    'about_apartments'=>$hotel_disc,
                    'smal_discription'=>$hotel_minidisc
                );
                $table ='hotel_list_content';
                $colum = 'title';
                $id=$hotel_select;
                update($table, $colum, $id, $arr);
            }














            if (isset($slider_title) && isset($slider_disc) && isset($slider_photo)){



                DB::table('maine_slider_content')->insert($arr);
            }
            $hotel_title = $request->input('slider_title');
            $hotel_disc = $request->input('slider_disc');
            $hotel_photo = $request->input('slider_photo');

            if (isset($slider_title) && isset($slider_disc) && isset($slider_photo)){

                $arr = array(
                    'photo'=>'slider_photo',
                    'title'=>'slider_title',
                    'text'=>'slider_disc'
                );

                DB::table('maine_slider_content')->insert($arr);
            }
            $slider_title = $request->input('slider_title');
            $slider_disc = $request->input('slider_disc');
            $slider_photo = $request->input('slider_photo');

            if (isset($slider_title) && isset($slider_disc) && isset($slider_photo)){

                $arr = array(
                    'photo'=>'slider_photo',
                    'title'=>'slider_title',
                    'text'=>'slider_disc'
                );

                DB::table('maine_slider_content')->insert($arr);
            }












            return view('AdminPages.maine',[
                'comment'=>$com,
                'room' =>$room,
                'slider' =>$slider,
                'ser' =>$ser

            ]);
        }
}
