<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentsList extends Model
{
    protected $table = 'comment_list_content';
}
