<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PreCom extends Model
{
    protected $table = 'precomment';
}
