<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderContact extends Model
{
    protected $table = 'contact_slider_content';
}
