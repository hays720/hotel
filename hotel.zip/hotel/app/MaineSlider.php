<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaineSlider extends Model
{
    protected $table = 'maine_slider_content';
}
