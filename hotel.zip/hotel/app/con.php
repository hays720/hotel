<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class con extends Model
{
    protected $table = 'Connect';
}
