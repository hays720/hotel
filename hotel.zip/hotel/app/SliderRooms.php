<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderRooms extends Model
{
    protected $table = 'slider_rooms_content';
}
